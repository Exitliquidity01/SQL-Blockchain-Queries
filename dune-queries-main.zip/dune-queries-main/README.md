DUNE Queries
